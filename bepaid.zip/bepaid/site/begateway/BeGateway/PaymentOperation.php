<?php
namespace BeGateway;

class PaymentOperation extends AuthorizationOperation {
}
?>
